/********************************************************
 * ADO.NET 2.0 Data Provider for SQLite Version 3.X
 * Written by Joe Mistachkin (joe@mistachkin.com)
 *
 * Released to the public domain, use at your own risk!
 ********************************************************/

using System.Data.SQLite;

///////////////////////////////////////////////////////////////////////////////

[assembly: AssemblySourceId("232ea198c84aec410b85c98b718b049b0b6913fd")]

///////////////////////////////////////////////////////////////////////////////

[assembly: AssemblySourceTimeStamp("2021-08-25 12:11:23 UTC")]
