/*
 * interop.h -
 *
 * Written by Joe Mistachkin.
 * Released to the public domain, use at your own risk!
 */

#ifndef INTEROP_VERSION
#define INTEROP_VERSION          "1.0.115.0"
#endif

#ifndef INTEROP_SOURCE_ID
#define INTEROP_SOURCE_ID        "232ea198c84aec410b85c98b718b049b0b6913fd"
#endif

#ifndef INTEROP_SOURCE_TIMESTAMP
#define INTEROP_SOURCE_TIMESTAMP "2021-08-25 12:11:23 UTC"
#endif
